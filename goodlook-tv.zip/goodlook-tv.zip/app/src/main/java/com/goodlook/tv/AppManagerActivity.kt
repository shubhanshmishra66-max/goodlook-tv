package com.goodlook.tv

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goodlook.tv.data.AppEntry
import com.goodlook.tv.data.AppRepository
import com.goodlook.tv.util.SettingsLauncher
import com.goodlook.tv.util.Ui
import java.util.concurrent.Executors

class AppManagerActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var grid: RecyclerView
    private lateinit var status: TextView
    private lateinit var countView: TextView
    private lateinit var searchInput: EditText
    private lateinit var sortButton: TextView
    private lateinit var adapter: AppAdapter

    private var allApps: List<AppEntry> = emptyList()
    private var loadedOnce = false
    private var query = ""
    private var ascending = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)

        grid = findViewById(R.id.appGrid)
        status = findViewById(R.id.appStatus)
        countView = findViewById(R.id.appCount)
        searchInput = findViewById(R.id.searchInput)
        sortButton = findViewById(R.id.sortButton)

        adapter = AppAdapter(
            onLaunch = { AppRepository.launch(this, it) },
            onSettings = { SettingsLauncher.openAppDetails(this, it.packageName) }
        )
        grid.layoutManager = GridLayoutManager(this, 5)
        grid.adapter = adapter

        Ui.applyFocus(searchInput, 1.02f)
        Ui.applyFocus(sortButton, 1.04f)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString().orEmpty()
                applyFilter()
            }
        })
        searchInput.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_SEARCH) {
                getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(v.windowToken, 0)
                focusFirstApp()
                true
            } else {
                false
            }
        }

        sortButton.setOnClickListener {
            ascending = !ascending
            sortButton.setText(if (ascending) R.string.sort_az else R.string.sort_za)
            applyFilter()
        }
    }

    override fun onStart() {
        super.onStart()
        loadApps()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun loadApps() {
        val appContext = applicationContext
        worker.execute {
            val apps = AppRepository.loadLaunchableApps(appContext)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) onAppsLoaded(apps)
            }
        }
    }

    private fun onAppsLoaded(apps: List<AppEntry>) {
        val unchanged = loadedOnce &&
            apps.map { it.packageName } == allApps.map { it.packageName }
        if (unchanged) return // nothing changed, keep the user's focus and scroll position

        allApps = apps
        applyFilter()
        if (!loadedOnce) {
            loadedOnce = true
            focusFirstApp()
        }
    }

    private fun applyFilter() {
        val q = query.trim()
        val filtered = if (q.isEmpty()) {
            allApps
        } else {
            allApps.filter { it.label.contains(q, ignoreCase = true) }
        }
        val sorted = if (ascending) {
            filtered.sortedBy { it.label.lowercase() }
        } else {
            filtered.sortedByDescending { it.label.lowercase() }
        }

        adapter.submit(sorted)
        countView.text = getString(R.string.apps_count, sorted.size, allApps.size)

        if (sorted.isEmpty()) {
            status.setText(if (allApps.isEmpty()) R.string.apps_empty else R.string.apps_no_match)
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
    }

    private fun focusFirstApp() {
        grid.post {
            grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
        }
    }
}
