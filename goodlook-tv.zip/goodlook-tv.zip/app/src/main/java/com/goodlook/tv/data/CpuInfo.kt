package com.goodlook.tv.data

import android.os.Build
import java.io.File

data class CpuStats(
    val cores: Int,
    val coreTypes: String?,
    val maxFreqMhz: Int?,
    val soc: String?
)

/**
 * Reads CPU details that Android/Linux expose to normal apps (no root).
 * Anything unreadable is returned as null and shown as "Not available".
 */
object CpuInfo {

    // Official ARM Ltd. part numbers (implementer 0x41).
    private val armParts = mapOf(
        0xc07 to "Cortex-A7",
        0xc09 to "Cortex-A9",
        0xc0f to "Cortex-A15",
        0xd03 to "Cortex-A53",
        0xd04 to "Cortex-A35",
        0xd05 to "Cortex-A55",
        0xd07 to "Cortex-A57",
        0xd08 to "Cortex-A72",
        0xd09 to "Cortex-A73",
        0xd0a to "Cortex-A75",
        0xd0b to "Cortex-A76",
        0xd0d to "Cortex-A77"
    )

    fun read(): CpuStats {
        val cores = Runtime.getRuntime().availableProcessors()
        val blocks = parseProcCpuInfo()
        return CpuStats(
            cores = cores,
            coreTypes = coreTypes(blocks),
            maxFreqMhz = maxFrequencyMhz(cores),
            soc = socName(blocks)
        )
    }

    private fun isValid(value: String?): Boolean =
        !value.isNullOrBlank() && !value.equals("unknown", ignoreCase = true)

    private fun parseProcCpuInfo(): List<Map<String, String>> {
        return try {
            val text = File("/proc/cpuinfo").bufferedReader().use { it.readText() }
            text.split("\n\n")
                .map { block ->
                    val map = HashMap<String, String>()
                    for (line in block.lines()) {
                        val index = line.indexOf(':')
                        if (index > 0) {
                            map[line.substring(0, index).trim()] = line.substring(index + 1).trim()
                        }
                    }
                    map
                }
                .filter { it.isNotEmpty() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseHex(value: String?): Int? {
        if (value == null) return null
        return value.trim().removePrefix("0x").removePrefix("0X").toIntOrNull(16)
    }

    private fun coreTypes(blocks: List<Map<String, String>>): String? {
        val counts = LinkedHashMap<String, Int>()
        for (block in blocks) {
            if (!block.containsKey("processor")) continue
            val part = parseHex(block["CPU part"])
            val implementer = parseHex(block["CPU implementer"])
            val name: String? = when {
                part != null && implementer == 0x41 ->
                    armParts[part] ?: "ARM part 0x" + part.toString(16)
                part != null -> "CPU part 0x" + part.toString(16)
                isValid(block["model name"]) -> block["model name"]
                else -> null
            }
            if (name != null) counts[name] = (counts[name] ?: 0) + 1
        }
        if (counts.isEmpty()) return null
        return counts.entries.joinToString(" + ") { "${it.value} × ${it.key}" }
    }

    private fun maxFrequencyMhz(cores: Int): Int? {
        var best: Long? = null
        for (i in 0 until cores) {
            try {
                val text = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
                    .bufferedReader().use { it.readText() }
                val khz = text.trim().toLongOrNull() ?: continue
                if (best == null || khz > best) best = khz
            } catch (e: Exception) {
                // not readable on this device
            }
        }
        val khz = best ?: return null
        return (khz / 1000).toInt()
    }

    private fun socName(blocks: List<Map<String, String>>): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val maker = Build.SOC_MANUFACTURER
            val model = Build.SOC_MODEL
            if (isValid(model)) {
                return if (isValid(maker)) "$maker $model" else model
            }
        }
        for (block in blocks) {
            val hardware = block["Hardware"]
            if (isValid(hardware)) return hardware
        }
        return if (isValid(Build.HARDWARE)) Build.HARDWARE else null
    }
}
