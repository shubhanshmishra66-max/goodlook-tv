package com.goodlook.tv.util

import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.animation.DecelerateInterpolator

object Ui {

    private val GLOW = Color.parseColor("#22D3EE")

    /** Smooth focus animation (scale + lift + cyan glow on Android 9+) for any focusable TV view. */
    fun applyFocus(view: View, scale: Float = 1.05f) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            view.defaultFocusHighlightEnabled = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            view.outlineSpotShadowColor = GLOW
            view.outlineAmbientShadowColor = GLOW
        }
        view.setOnFocusChangeListener { v, hasFocus ->
            v.animate()
                .scaleX(if (hasFocus) scale else 1f)
                .scaleY(if (hasFocus) scale else 1f)
                .translationZ(if (hasFocus) 24f else 0f)
                .setDuration(180)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }
}
