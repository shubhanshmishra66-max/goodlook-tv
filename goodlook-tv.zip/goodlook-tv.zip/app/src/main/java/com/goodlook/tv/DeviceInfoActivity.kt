package com.goodlook.tv

import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.widget.TextView
import android.widget.Toast
import com.goodlook.tv.data.CpuInfo
import com.goodlook.tv.data.SystemInfo

class DeviceInfoActivity : SectionActivity() {

    override val titleRes = R.string.card_device
    override val subtitleRes = R.string.sub_device
    override val iconRes = R.drawable.ic_tv

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) {
                refresh()
                handler.postDelayed(this, 3000)
            }
        }
    }

    private var ramAvailable: TextView? = null
    private var ramState: TextView? = null
    private var storageTotal: TextView? = null
    private var storageUsed: TextView? = null
    private var storageFree: TextView? = null

    private fun orUnknown(value: String?): String =
        if (value.isNullOrBlank()) getString(R.string.unknown) else value

    override fun build() {
        val na = getString(R.string.not_available)

        addAction(getString(R.string.action_refresh), getString(R.string.action_refresh_sub)) {
            refresh()
            Toast.makeText(this, R.string.refreshed, Toast.LENGTH_SHORT).show()
        }

        // Device
        addSection(R.string.sec_device)
        addRow(getString(R.string.label_manufacturer), orUnknown(Build.MANUFACTURER))
        addRow(getString(R.string.label_model), orUnknown(Build.MODEL))
        addRow(getString(R.string.label_brand), orUnknown(Build.BRAND))
        addRow(getString(R.string.label_device), orUnknown(Build.DEVICE))
        val dm = resources.displayMetrics
        addRow(
            getString(R.string.label_display),
            getString(R.string.display_format, dm.widthPixels, dm.heightPixels, dm.densityDpi)
        )
        val isTv = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        addRow(getString(R.string.label_tv), getString(if (isTv) R.string.yes else R.string.no))

        // Software
        addSection(R.string.sec_software)
        addRow(getString(R.string.label_android), orUnknown(Build.VERSION.RELEASE))
        addRow(getString(R.string.label_sdk), Build.VERSION.SDK_INT.toString())
        addRow(getString(R.string.label_patch), orUnknown(Build.VERSION.SECURITY_PATCH))
        addRow(getString(R.string.label_build), orUnknown(Build.DISPLAY))

        // Processor
        addSection(R.string.sec_processor)
        val cpu = CpuInfo.read()
        addRow(getString(R.string.label_soc), cpu.soc ?: na)
        addRow(getString(R.string.label_abi), orUnknown(Build.SUPPORTED_ABIS.joinToString(", ")))
        addRow(getString(R.string.label_cpu_cores), cpu.cores.toString())
        addRow(getString(R.string.label_cpu_types), cpu.coreTypes ?: na)
        addRow(
            getString(R.string.label_cpu_freq),
            cpu.maxFreqMhz?.let { getString(R.string.freq_format, it) } ?: na
        )

        // Memory
        addSection(R.string.sec_memory)
        val memory = SystemInfo.memory(this)
        addRow(
            getString(R.string.label_ram_total),
            if (memory != null) Formatter.formatFileSize(this, memory.total) else na
        )
        ramAvailable = addRow(getString(R.string.label_ram_avail), na)
        ramState = addRow(getString(R.string.label_ram_state), na)
        addRow(
            getString(R.string.label_ram_class),
            if (memory != null) getString(R.string.mb_format, memory.appMemoryClassMb) else na
        )

        // Storage (live)
        addSection(R.string.sec_storage)
        storageTotal = addRow(getString(R.string.label_total), na)
        storageUsed = addRow(getString(R.string.label_used), na)
        storageFree = addRow(getString(R.string.label_free), na)

        addNote(getString(R.string.note_cpu))
        addNote(getString(R.string.note_ram))
    }

    override fun refresh() {
        val na = getString(R.string.not_available)

        val memory = SystemInfo.memory(this)
        if (memory != null) {
            ramAvailable?.text = Formatter.formatFileSize(this, memory.available)
            ramState?.setText(if (memory.lowMemory) R.string.value_mem_low else R.string.value_mem_normal)
        } else {
            ramAvailable?.text = na
            ramState?.text = na
        }

        val storage = SystemInfo.storage()
        if (storage != null) {
            storageTotal?.text = Formatter.formatFileSize(this, storage.total)
            storageUsed?.text = Formatter.formatFileSize(this, storage.used)
            storageFree?.text = Formatter.formatFileSize(this, storage.free)
        } else {
            storageTotal?.text = na
            storageUsed?.text = na
            storageFree?.text = na
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 3000)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
