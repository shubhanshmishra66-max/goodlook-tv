package com.goodlook.tv

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.goodlook.tv.data.AppRepository
import com.goodlook.tv.data.LinkType
import com.goodlook.tv.data.SystemInfo
import com.goodlook.tv.data.label
import com.goodlook.tv.util.Ui
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val liveTicker = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) {
                refreshLive()
                handler.postDelayed(this, 5000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupCard(R.id.cardDevice, R.drawable.ic_tv, R.string.card_device, DeviceInfoActivity::class.java)
        setupCard(R.id.cardStorage, R.drawable.ic_storage, R.string.card_storage, StorageActivity::class.java)
        setupCard(R.id.cardNetwork, R.drawable.ic_wifi, R.string.card_network, NetworkActivity::class.java)
        setupCard(R.id.cardApps, R.drawable.ic_apps, R.string.card_apps, AppManagerActivity::class.java)
        setupCard(R.id.cardTools, R.drawable.ic_settings, R.string.card_tools, SystemToolsActivity::class.java)
        setupCard(R.id.cardAbout, R.drawable.ic_info, R.string.card_about, AboutActivity::class.java)

        findViewById<View>(R.id.cardDevice).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        refreshLive()
        refreshAppCount()
        handler.removeCallbacks(liveTicker)
        handler.postDelayed(liveTicker, 5000)
    }

    override fun onPause() {
        handler.removeCallbacks(liveTicker)
        super.onPause()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun setupCard(cardId: Int, iconRes: Int, titleRes: Int, target: Class<*>) {
        val card = findViewById<View>(cardId)
        card.findViewById<ImageView>(R.id.cardIcon).setImageResource(iconRes)
        card.findViewById<TextView>(R.id.cardTitle).setText(titleRes)
        Ui.applyFocus(card, 1.06f)
        card.setOnClickListener { startActivity(Intent(this, target)) }
    }

    private fun setSummary(cardId: Int, text: String) {
        findViewById<View>(cardId).findViewById<TextView>(R.id.cardSummary).text = text
    }

    /** Values that change while the dashboard is open: RAM, storage, network. */
    private fun refreshLive() {
        // Device (with live RAM when Android reports it)
        val memory = SystemInfo.memory(this)
        val deviceText = if (memory != null) {
            getString(
                R.string.summary_device_ram,
                SystemInfo.deviceName(),
                Build.VERSION.RELEASE,
                Build.VERSION.SDK_INT,
                Formatter.formatFileSize(this, memory.available),
                Formatter.formatFileSize(this, memory.total)
            )
        } else {
            getString(R.string.summary_device, SystemInfo.deviceName(), Build.VERSION.RELEASE, Build.VERSION.SDK_INT)
        }
        setSummary(R.id.cardDevice, deviceText)

        // Storage
        val storage = SystemInfo.storage()
        val bar = findViewById<View>(R.id.cardStorage).findViewById<ProgressBar>(R.id.cardProgress)
        if (storage != null) {
            setSummary(
                R.id.cardStorage,
                getString(
                    R.string.summary_storage,
                    Formatter.formatFileSize(this, storage.free),
                    Formatter.formatFileSize(this, storage.total)
                )
            )
            bar.progress = storage.percentUsed
            bar.visibility = View.VISIBLE
        } else {
            setSummary(R.id.cardStorage, getString(R.string.summary_storage_unavailable))
            bar.visibility = View.GONE
        }

        // Network
        val net = SystemInfo.network(this)
        val typeLabel = net.type.label(this)
        val networkText = when {
            net.type == LinkType.NONE -> getString(R.string.value_disconnected)
            net.ipv4 != null -> getString(R.string.summary_network_connected, typeLabel, net.ipv4)
            else -> getString(R.string.summary_network_no_ip, typeLabel)
        }
        setSummary(R.id.cardNetwork, networkText)

        // Tools + About
        setSummary(R.id.cardTools, getString(R.string.summary_tools))
        setSummary(R.id.cardAbout, getString(R.string.summary_about, SystemInfo.appVersionName(this)))
    }

    /** Apps are counted off the main thread. */
    private fun refreshAppCount() {
        setSummary(R.id.cardApps, getString(R.string.summary_apps_loading))
        val appContext = applicationContext
        worker.execute {
            val count = AppRepository.countLaunchable(appContext)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    setSummary(R.id.cardApps, getString(R.string.summary_apps, count))
                }
            }
        }
    }
}
