package com.goodlook.tv.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.goodlook.tv.R

object SettingsLauncher {

    /**
     * Tries each settings action in order. If the device has none of them
     * (common on some TV firmwares) a friendly message is shown instead of crashing.
     */
    fun open(context: Context, vararg actions: String): Boolean {
        for (action in actions) {
            try {
                context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: ActivityNotFoundException) {
                // try next action
            } catch (e: SecurityException) {
                // try next action
            }
        }
        Toast.makeText(context, R.string.settings_unsupported, Toast.LENGTH_LONG).show()
        return false
    }

    fun openAppDetails(context: Context, packageName: String): Boolean {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null)
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.settings_unsupported, Toast.LENGTH_LONG).show()
            false
        } catch (e: SecurityException) {
            Toast.makeText(context, R.string.settings_unsupported, Toast.LENGTH_LONG).show()
            false
        }
    }

    fun openStorage(context: Context) = open(
        context,
        Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        Settings.ACTION_MEMORY_CARD_SETTINGS,
        Settings.ACTION_SETTINGS
    )

    fun openNetwork(context: Context) = open(
        context,
        Settings.ACTION_WIFI_SETTINGS,
        Settings.ACTION_WIRELESS_SETTINGS,
        Settings.ACTION_SETTINGS
    )

    fun openDisplay(context: Context) = open(context, Settings.ACTION_DISPLAY_SETTINGS)
    fun openSound(context: Context) = open(context, Settings.ACTION_SOUND_SETTINGS)
    fun openBluetooth(context: Context) = open(context, Settings.ACTION_BLUETOOTH_SETTINGS)
    fun openSystem(context: Context) = open(context, Settings.ACTION_SETTINGS)
}
