package com.goodlook.tv

import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.goodlook.tv.data.SystemInfo
import com.goodlook.tv.data.label
import com.goodlook.tv.util.SettingsLauncher

class NetworkActivity : SectionActivity() {

    override val titleRes = R.string.card_network
    override val subtitleRes = R.string.sub_network
    override val iconRes = R.drawable.ic_wifi

    private lateinit var statusValue: TextView
    private lateinit var typeValue: TextView
    private lateinit var wifiValue: TextView
    private lateinit var ipv4Value: TextView
    private lateinit var ipv6Value: TextView
    private lateinit var speedValue: TextView
    private lateinit var signalValue: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = Runnable { if (!isFinishing && !isDestroyed) refresh() }
    private var callback: ConnectivityManager.NetworkCallback? = null

    override fun build() {
        statusValue = addRow(getString(R.string.label_conn_status), "")
        typeValue = addRow(getString(R.string.label_net_type), "")
        wifiValue = addRow(getString(R.string.label_wifi_radio), "")
        ipv4Value = addRow(getString(R.string.label_ipv4), "")
        ipv6Value = addRow(getString(R.string.label_ipv6), "")
        speedValue = addRow(getString(R.string.label_link_speed), "")
        signalValue = addRow(getString(R.string.label_signal), "")

        addAction(
            getString(R.string.action_open_network),
            getString(R.string.action_open_network_sub)
        ) { SettingsLauncher.openNetwork(this) }

        addNote(getString(R.string.note_network))
    }

    override fun refresh() {
        val net = SystemInfo.network(this)
        val na = getString(R.string.not_available)

        statusValue.text = when {
            !net.connected -> getString(R.string.value_disconnected)
            net.internetValidated -> getString(R.string.value_connected_internet)
            else -> getString(R.string.value_connected_limited)
        }
        typeValue.text = net.type.label(this)
        wifiValue.text = when (net.wifiEnabled) {
            true -> getString(R.string.value_enabled)
            false -> getString(R.string.value_disabled)
            null -> na
        }
        ipv4Value.text = net.ipv4 ?: na
        ipv6Value.text = net.ipv6 ?: na
        speedValue.text = net.wifiLinkSpeedMbps?.let { getString(R.string.speed_format, it) } ?: na
        signalValue.text = net.wifiRssiDbm?.let { getString(R.string.rssi_format, it) } ?: na
    }

    override fun onStart() {
        super.onStart()
        registerCallback()
    }

    override fun onStop() {
        unregisterCallback()
        handler.removeCallbacks(refreshRunnable)
        super.onStop()
    }

    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 400)
    }

    private fun registerCallback() {
        if (callback != null) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = scheduleRefresh()
            override fun onLost(network: Network) = scheduleRefresh()
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) =
                scheduleRefresh()

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) =
                scheduleRefresh()
        }
        try {
            cm.registerNetworkCallback(NetworkRequest.Builder().build(), cb)
            callback = cb
        } catch (e: Exception) {
            // Live updates unavailable; values still refresh when the screen is reopened.
        }
    }

    private fun unregisterCallback() {
        val cb = callback ?: return
        try {
            getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb)
        } catch (e: Exception) {
            // already unregistered
        }
        callback = null
    }
}
