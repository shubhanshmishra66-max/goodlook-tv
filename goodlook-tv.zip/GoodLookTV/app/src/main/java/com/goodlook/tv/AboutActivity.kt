package com.goodlook.tv

import com.goodlook.tv.data.SystemInfo

class AboutActivity : SectionActivity() {

    override val titleRes = R.string.card_about
    override val subtitleRes = R.string.sub_about
    override val iconRes = R.drawable.ic_info

    override fun build() {
        addRow(getString(R.string.label_app_name), getString(R.string.app_name))
        addRow(getString(R.string.label_version), SystemInfo.appVersionLabel(this))
        addRow(getString(R.string.label_package), packageName)
        addRow(getString(R.string.label_developer), getString(R.string.value_developer))
        addRow(getString(R.string.label_built_with), getString(R.string.value_built_with))
        addRow(getString(R.string.label_target_sdk), applicationInfo.targetSdkVersion.toString())
        addNote(getString(R.string.note_about))
    }
}
