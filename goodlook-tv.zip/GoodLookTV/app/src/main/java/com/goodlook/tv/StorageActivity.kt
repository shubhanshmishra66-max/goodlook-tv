package com.goodlook.tv

import android.text.format.Formatter
import android.widget.ProgressBar
import android.widget.TextView
import com.goodlook.tv.data.SystemInfo
import com.goodlook.tv.util.SettingsLauncher

class StorageActivity : SectionActivity() {

    override val titleRes = R.string.card_storage
    override val subtitleRes = R.string.sub_storage
    override val iconRes = R.drawable.ic_storage

    private lateinit var headline: TextView
    private lateinit var subhead: TextView
    private lateinit var bar: ProgressBar
    private lateinit var totalValue: TextView
    private lateinit var usedValue: TextView
    private lateinit var freeValue: TextView

    override fun build() {
        val card = addCustom(R.layout.item_storage_bar)
        headline = card.findViewById(R.id.storageHeadline)
        subhead = card.findViewById(R.id.storageSubhead)
        bar = card.findViewById(R.id.storageBar)

        totalValue = addRow(getString(R.string.label_total), "")
        usedValue = addRow(getString(R.string.label_used), "")
        freeValue = addRow(getString(R.string.label_free), "")

        addAction(
            getString(R.string.action_open_storage),
            getString(R.string.action_open_storage_sub)
        ) { SettingsLauncher.openStorage(this) }

        addNote(getString(R.string.note_storage))
    }

    override fun refresh() {
        val stats = SystemInfo.storage()
        if (stats == null) {
            val na = getString(R.string.not_available)
            headline.text = na
            subhead.text = ""
            bar.progress = 0
            totalValue.text = na
            usedValue.text = na
            freeValue.text = na
            return
        }
        val total = Formatter.formatFileSize(this, stats.total)
        val used = Formatter.formatFileSize(this, stats.used)
        val free = Formatter.formatFileSize(this, stats.free)
        headline.text = getString(R.string.storage_percent_used, stats.percentUsed)
        subhead.text = getString(R.string.storage_of, used, total)
        bar.progress = stats.percentUsed
        totalValue.text = total
        usedValue.text = used
        freeValue.text = free
    }
}
