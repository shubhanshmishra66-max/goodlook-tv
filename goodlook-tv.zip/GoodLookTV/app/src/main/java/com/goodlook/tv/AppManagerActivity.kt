package com.goodlook.tv

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goodlook.tv.data.AppEntry
import com.goodlook.tv.data.AppRepository
import com.goodlook.tv.util.SettingsLauncher
import java.util.concurrent.Executors

class AppManagerActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var grid: RecyclerView
    private lateinit var status: TextView
    private lateinit var adapter: AppAdapter
    private var shownPackages: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)

        grid = findViewById(R.id.appGrid)
        status = findViewById(R.id.appStatus)

        adapter = AppAdapter(
            onLaunch = { AppRepository.launch(this, it) },
            onSettings = { SettingsLauncher.openAppDetails(this, it.packageName) }
        )
        grid.layoutManager = GridLayoutManager(this, 5)
        grid.adapter = adapter
    }

    override fun onStart() {
        super.onStart()
        loadApps()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun loadApps() {
        val appContext = applicationContext
        worker.execute {
            val apps = AppRepository.loadLaunchableApps(appContext)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) showApps(apps)
            }
        }
    }

    private fun showApps(apps: List<AppEntry>) {
        val packages = apps.map { it.packageName }
        if (packages == shownPackages && apps.isNotEmpty()) return // nothing changed, keep focus
        shownPackages = packages

        adapter.submit(apps)
        if (apps.isEmpty()) {
            status.setText(R.string.apps_empty)
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
            grid.post {
                grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
            }
        }
    }
}
