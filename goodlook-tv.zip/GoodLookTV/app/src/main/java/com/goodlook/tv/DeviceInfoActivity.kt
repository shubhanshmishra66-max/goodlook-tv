package com.goodlook.tv

import android.content.pm.PackageManager
import android.os.Build
import android.text.format.Formatter
import android.widget.TextView
import com.goodlook.tv.data.SystemInfo

class DeviceInfoActivity : SectionActivity() {

    override val titleRes = R.string.card_device
    override val subtitleRes = R.string.sub_device
    override val iconRes = R.drawable.ic_tv

    private var ramAvailable: TextView? = null
    private var ramState: TextView? = null

    private fun orUnknown(value: String?): String =
        if (value.isNullOrBlank()) getString(R.string.unknown) else value

    override fun build() {
        addRow(getString(R.string.label_manufacturer), orUnknown(Build.MANUFACTURER))
        addRow(getString(R.string.label_model), orUnknown(Build.MODEL))
        addRow(getString(R.string.label_brand), orUnknown(Build.BRAND))
        addRow(getString(R.string.label_device), orUnknown(Build.DEVICE))
        addRow(getString(R.string.label_hardware), orUnknown(Build.HARDWARE))
        addRow(getString(R.string.label_android), orUnknown(Build.VERSION.RELEASE))
        addRow(getString(R.string.label_sdk), Build.VERSION.SDK_INT.toString())
        addRow(getString(R.string.label_patch), orUnknown(Build.VERSION.SECURITY_PATCH))
        addRow(getString(R.string.label_build), orUnknown(Build.DISPLAY))
        addRow(getString(R.string.label_abi), orUnknown(Build.SUPPORTED_ABIS.joinToString(", ")))

        val dm = resources.displayMetrics
        addRow(
            getString(R.string.label_display),
            getString(R.string.display_format, dm.widthPixels, dm.heightPixels, dm.densityDpi)
        )

        val isTv = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        addRow(getString(R.string.label_tv), getString(if (isTv) R.string.yes else R.string.no))

        val memory = SystemInfo.memory(this)
        val notAvailable = getString(R.string.not_available)
        addRow(
            getString(R.string.label_ram_total),
            if (memory != null) Formatter.formatFileSize(this, memory.total) else notAvailable
        )
        ramAvailable = addRow(getString(R.string.label_ram_avail), notAvailable)
        ramState = addRow(getString(R.string.label_ram_state), notAvailable)
        addRow(
            getString(R.string.label_ram_class),
            if (memory != null) getString(R.string.mb_format, memory.appMemoryClassMb) else notAvailable
        )

        addNote(getString(R.string.note_ram))
    }

    override fun refresh() {
        val memory = SystemInfo.memory(this) ?: return
        ramAvailable?.text = Formatter.formatFileSize(this, memory.available)
        ramState?.setText(if (memory.lowMemory) R.string.value_mem_low else R.string.value_mem_normal)
    }
}
