package com.goodlook.tv.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.goodlook.tv.R
import java.net.Inet4Address
import java.net.Inet6Address

data class StorageStats(val total: Long, val used: Long, val free: Long) {
    val percentUsed: Int
        get() = if (total > 0) ((used * 100) / total).toInt() else 0
}

data class MemoryStats(
    val total: Long,
    val available: Long,
    val lowMemory: Boolean,
    val appMemoryClassMb: Int
)

enum class LinkType { WIFI, ETHERNET, CELLULAR, BLUETOOTH, VPN, OTHER, NONE }

data class NetworkStats(
    val type: LinkType,
    val connected: Boolean,
    val internetValidated: Boolean,
    val wifiEnabled: Boolean?,
    val ipv4: String?,
    val ipv6: String?,
    val wifiLinkSpeedMbps: Int?,
    val wifiRssiDbm: Int?
)

fun LinkType.label(context: Context): String = context.getString(
    when (this) {
        LinkType.WIFI -> R.string.net_wifi
        LinkType.ETHERNET -> R.string.net_ethernet
        LinkType.CELLULAR -> R.string.net_cellular
        LinkType.BLUETOOTH -> R.string.net_bluetooth
        LinkType.VPN -> R.string.net_vpn
        LinkType.OTHER -> R.string.net_other
        LinkType.NONE -> R.string.net_none
    }
)

/** Reads only real values exposed by Android. Nothing here is estimated or faked. */
object SystemInfo {

    fun deviceName(): String {
        val maker = Build.MANUFACTURER.orEmpty().trim()
        val model = Build.MODEL.orEmpty().trim()
        val name = when {
            model.isEmpty() -> maker
            maker.isEmpty() || model.startsWith(maker, ignoreCase = true) -> model
            else -> maker.replaceFirstChar { it.uppercase() } + " " + model
        }
        return name.ifBlank { "Android device" }
    }

    fun storage(): StorageStats? {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            StorageStats(total = total, used = total - free, free = free)
        } catch (e: Exception) {
            null
        }
    }

    fun memory(context: Context): MemoryStats? {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return null
        return try {
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            MemoryStats(info.totalMem, info.availMem, info.lowMemory, am.memoryClass)
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    fun network(context: Context): NetworkStats {
        val app = context.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val wm = app.getSystemService(Context.WIFI_SERVICE) as? WifiManager

        val wifiEnabled: Boolean? = try {
            wm?.isWifiEnabled
        } catch (e: Exception) {
            null
        }

        val network = try {
            cm?.activeNetwork
        } catch (e: Exception) {
            null
        }
        val caps = try {
            if (network != null) cm?.getNetworkCapabilities(network) else null
        } catch (e: Exception) {
            null
        }

        if (network == null || caps == null) {
            return NetworkStats(LinkType.NONE, false, false, wifiEnabled, null, null, null, null)
        }

        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> LinkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> LinkType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> LinkType.CELLULAR
            caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> LinkType.BLUETOOTH
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> LinkType.VPN
            else -> LinkType.OTHER
        }
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

        var v4: String? = null
        var v6: String? = null
        try {
            val props = cm?.getLinkProperties(network)
            props?.linkAddresses?.forEach { linkAddress ->
                val addr = linkAddress.address
                if (addr.isLoopbackAddress) return@forEach
                if (addr is Inet4Address) {
                    if (v4 == null) v4 = addr.hostAddress
                } else if (addr is Inet6Address) {
                    if (v6 == null && !addr.isLinkLocalAddress) {
                        v6 = addr.hostAddress?.substringBefore('%')
                    }
                }
            }
        } catch (e: Exception) {
            // IP not readable on this device
        }

        var speed: Int? = null
        var rssi: Int? = null
        if (type == LinkType.WIFI) {
            try {
                val info = wm?.connectionInfo
                speed = info?.linkSpeed?.takeIf { it > 0 }
                rssi = info?.rssi?.takeIf { it < 0 && it > -127 }
            } catch (e: Exception) {
                // Wi-Fi details not readable on this device
            }
        }

        return NetworkStats(type, true, validated, wifiEnabled, v4, v6, speed, rssi)
    }

    @Suppress("DEPRECATION")
    fun appPackageInfo(context: Context): PackageInfo? {
        return try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageInfo(context.packageName, 0)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun appVersionName(context: Context): String =
        appPackageInfo(context)?.versionName ?: context.getString(R.string.unknown)

    @Suppress("DEPRECATION")
    fun appVersionLabel(context: Context): String {
        val info = appPackageInfo(context) ?: return context.getString(R.string.unknown)
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            info.versionCode.toLong()
        }
        return "${info.versionName ?: context.getString(R.string.unknown)} ($code)"
    }
}
