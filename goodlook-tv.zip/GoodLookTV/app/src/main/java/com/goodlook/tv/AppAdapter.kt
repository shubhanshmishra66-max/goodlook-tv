package com.goodlook.tv

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goodlook.tv.data.AppEntry
import com.goodlook.tv.util.Ui

class AppAdapter(
    private val onLaunch: (AppEntry) -> Unit,
    private val onSettings: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    private var items: List<AppEntry> = emptyList()

    fun submit(list: List<AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        Ui.applyFocus(view, 1.08f)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.icon.setImageDrawable(entry.icon)
        holder.label.text = entry.label

        holder.itemView.setOnClickListener { onLaunch(entry) }
        // Hold OK on the remote
        holder.itemView.setOnLongClickListener {
            onSettings(entry)
            true
        }
        // Menu / Info key on the remote
        holder.itemView.setOnKeyListener { _, keyCode, event ->
            if ((keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO) &&
                event.action == KeyEvent.ACTION_UP
            ) {
                onSettings(entry)
                true
            } else {
                false
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
