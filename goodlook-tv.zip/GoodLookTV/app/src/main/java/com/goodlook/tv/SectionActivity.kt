package com.goodlook.tv

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.goodlook.tv.util.Ui

/**
 * Base class for every detail screen. Builds a header and a vertical list of
 * focusable cards so the whole screen can be navigated and scrolled with a D-pad.
 */
abstract class SectionActivity : AppCompatActivity() {

    protected lateinit var content: LinearLayout

    protected abstract val titleRes: Int
    protected abstract val subtitleRes: Int
    protected abstract val iconRes: Int

    /** Called once: create rows and actions. */
    protected abstract fun build()

    /** Called every time the screen becomes visible: update live values. */
    protected open fun refresh() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_section)
        findViewById<ImageView>(R.id.sectionIcon).setImageResource(iconRes)
        findViewById<TextView>(R.id.sectionTitle).setText(titleRes)
        findViewById<TextView>(R.id.sectionSubtitle).setText(subtitleRes)
        content = findViewById(R.id.content)
        build()
        content.getChildAt(0)?.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    protected fun addRow(label: String, value: String): TextView {
        val row = layoutInflater.inflate(R.layout.item_info_row, content, false)
        row.findViewById<TextView>(R.id.rowLabel).text = label
        val valueView = row.findViewById<TextView>(R.id.rowValue)
        valueView.text = value
        Ui.applyFocus(row, 1.02f)
        content.addView(row)
        return valueView
    }

    protected fun addAction(title: String, subtitle: String, onClick: () -> Unit) {
        val card = layoutInflater.inflate(R.layout.item_action, content, false)
        card.findViewById<TextView>(R.id.actionTitle).text = title
        card.findViewById<TextView>(R.id.actionSubtitle).text = subtitle
        card.setOnClickListener { onClick() }
        Ui.applyFocus(card, 1.02f)
        content.addView(card)
    }

    protected fun addNote(text: String) {
        val note = layoutInflater.inflate(R.layout.item_note, content, false) as TextView
        note.text = text
        Ui.applyFocus(note, 1.02f)
        content.addView(note)
    }

    protected fun addCustom(layoutRes: Int, scale: Float = 1.02f): View {
        val view = layoutInflater.inflate(layoutRes, content, false)
        Ui.applyFocus(view, scale)
        content.addView(view)
        return view
    }
}
