package com.goodlook.tv.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.widget.Toast
import com.goodlook.tv.R

data class AppEntry(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

object AppRepository {

    private val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)

    @Suppress("DEPRECATION")
    fun loadLaunchableApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val result = LinkedHashMap<String, AppEntry>()
        for (category in categories) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (info in pm.queryIntentActivities(intent, 0)) {
                val ai = info.activityInfo ?: continue
                if (result.containsKey(ai.packageName)) continue
                result[ai.packageName] = AppEntry(
                    label = info.loadLabel(pm).toString(),
                    packageName = ai.packageName,
                    activityName = ai.name,
                    icon = info.loadIcon(pm)
                )
            }
        }
        return result.values.sortedBy { it.label.lowercase() }
    }

    @Suppress("DEPRECATION")
    fun countLaunchable(context: Context): Int {
        val pm = context.packageManager
        val packages = HashSet<String>()
        for (category in categories) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (info in pm.queryIntentActivities(intent, 0)) {
                info.activityInfo?.packageName?.let { packages.add(it) }
            }
        }
        return packages.size
    }

    fun launch(context: Context, entry: AppEntry): Boolean {
        val intent = Intent(Intent.ACTION_MAIN)
            .setClassName(entry.packageName, entry.activityName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            failed(context, entry)
        } catch (e: SecurityException) {
            failed(context, entry)
        }
    }

    private fun failed(context: Context, entry: AppEntry): Boolean {
        Toast.makeText(
            context,
            context.getString(R.string.app_launch_failed, entry.label),
            Toast.LENGTH_LONG
        ).show()
        return false
    }
}
