package com.goodlook.tv.util

import android.os.Build
import android.view.View
import android.view.animation.DecelerateInterpolator

object Ui {

    /** Smooth focus animation (scale + lift) for any focusable TV view. */
    fun applyFocus(view: View, scale: Float = 1.05f) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            view.defaultFocusHighlightEnabled = false
        }
        view.setOnFocusChangeListener { v, hasFocus ->
            v.animate()
                .scaleX(if (hasFocus) scale else 1f)
                .scaleY(if (hasFocus) scale else 1f)
                .translationZ(if (hasFocus) 16f else 0f)
                .setDuration(160)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }
}
