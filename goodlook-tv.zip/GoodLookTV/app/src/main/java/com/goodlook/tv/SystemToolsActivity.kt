package com.goodlook.tv

import com.goodlook.tv.util.SettingsLauncher

class SystemToolsActivity : SectionActivity() {

    override val titleRes = R.string.card_tools
    override val subtitleRes = R.string.sub_tools
    override val iconRes = R.drawable.ic_settings

    override fun build() {
        addAction(getString(R.string.tool_display), getString(R.string.tool_display_sub)) {
            SettingsLauncher.openDisplay(this)
        }
        addAction(getString(R.string.tool_sound), getString(R.string.tool_sound_sub)) {
            SettingsLauncher.openSound(this)
        }
        addAction(getString(R.string.tool_bluetooth), getString(R.string.tool_bluetooth_sub)) {
            SettingsLauncher.openBluetooth(this)
        }
        addAction(getString(R.string.tool_system), getString(R.string.tool_system_sub)) {
            SettingsLauncher.openSystem(this)
        }
    }
}
